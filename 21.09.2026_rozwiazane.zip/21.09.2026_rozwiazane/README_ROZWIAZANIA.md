# Rozwiązane zadania – 21.09.2026

Gotowe zadania z katalogu `Bootstrap_js/nauka`:

1. hamburger
2. collapse
3. dropdown
4. modal
5. accordion
6. tabs
7. dwie strony

Wszystkie strony używają Bootstrap 5.3.3 z CDN i `bootstrap.bundle.min.js`.
Pole autora pozostawiono jako `Imię Nazwisko klasa`, zgodnie z szablonami.
